import React from 'react';
import './HorizontalLine.css';

const HorizontalLine = () => {
    return (
        <div className='HorizontalLine'></div>
    )
}

export default HorizontalLine;